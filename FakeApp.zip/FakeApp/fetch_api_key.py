import subprocess
import json
import re
import time

CONFIG_FILE = 'config.json'

def get_new_api_key_from_logs():
    try:
        result = subprocess.run(['docker', 'logs', 'mobsf'], capture_output=True, text=True)
        logs = result.stdout

        for line in logs.splitlines():
            if "API Key:" in line:
                api_key = line.split("API Key:")[1].strip()
                # Remove ANSI escape codes
                api_key = re.sub(r'\x1B\[[0-?]*[ -/]*[@-~]', '', api_key)
                print(f"API Key found: {api_key}")
                return api_key

        print("API Key not found in the logs.")
        return None
    except Exception as e:
        print(f"Error fetching logs: {e}")
        return None

def update_api_key_in_config(new_api_key):
    try:
        with open(CONFIG_FILE, 'r') as file:
            config = json.load(file)

        config['MOBSF_API_KEY'] = new_api_key

        with open(CONFIG_FILE, 'w') as file:
            json.dump(config, file, indent=4)

        print(f"API key updated in config file: {new_api_key}")
    except Exception as e:
        print(f"Error updating config file: {e}")

if __name__ == '__main__':
    time.sleep(20)
    new_api_key = get_new_api_key_from_logs()
    if new_api_key:
        update_api_key_in_config(new_api_key)
    else:
        print("Failed to retrieve the API key.")
