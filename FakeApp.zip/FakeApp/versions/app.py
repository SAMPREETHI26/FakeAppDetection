from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import requests
import json
import os

app = Flask(__name__)
app.secret_key = 'supersecretkey'

CONFIG_FILE = 'config.json'

def load_config():
    try:
        with open(CONFIG_FILE, 'r') as file:
            config = json.load(file)
        return config
    except Exception as e:
        print(f"Error loading config file: {e}")
        return None

config = load_config()
MOBSF_API_KEY = config.get('MOBSF_API_KEY') if config else None
API_URL = 'http://localhost:8000/api/v1'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        flash('No file part')
        return redirect(request.url)
    
    file = request.files['file']
    if file.filename == '':
        flash('No selected file')
        return redirect(request.url)
    
    if file:
        files = {'file': (file.filename, file, 'application/vnd.android.package-archive')}
        response = send_request('/upload', 'POST', files=files)
        if response:
            scan_hash = response.get('hash')
            flash(f'File uploaded. Scan hash: {scan_hash}')
            return redirect(url_for('index'))
        else:
            flash('Failed to upload the file.')
            return redirect(url_for('index'))

@app.route('/scan', methods=['POST'])
def scan_file():
    scan_hash = request.form.get('scan_hash')
    if scan_hash:
        response = send_request('/scan', 'POST', data={'hash': scan_hash})
        if response:
            flash('File scanned successfully.')
        else:
            flash('Failed to scan the file.')
    else:
        flash('Please provide a scan hash.')
    return redirect(url_for('index'))

@app.route('/scorecard', methods=['POST'])
def get_scorecard():
    scan_hash = request.form.get('scan_hash')
    if scan_hash:
        response = send_request('/scorecard', 'POST', data={'hash': scan_hash})
        if response:
            return jsonify(response)
        else:
            flash('Failed to retrieve the scorecard.')
    else:
        flash('Please provide a scan hash.')
    return redirect(url_for('index'))

@app.route('/report_json', methods=['POST'])
def generate_json_report():
    scan_hash = request.form.get('scan_hash')
    if scan_hash:
        response = send_request('/report_json', 'POST', data={'hash': scan_hash})
        if response:
            return jsonify(response)
        else:
            flash('Failed to generate JSON report.')
    else:
        flash('Please provide a scan hash.')
    return redirect(url_for('index'))

def send_request(endpoint, method='GET', files=None, data=None, params=None):
    url = f'{API_URL}{endpoint}'
    headers = {'Authorization': MOBSF_API_KEY}
    try:
        if method == 'POST':
            if files:
                response = requests.post(url, headers=headers, files=files)
            else:
                response = requests.post(url, headers=headers, data=data)
        elif method == 'GET':
            response = requests.get(url, headers=headers, params=params)
        
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 401:
            flash('Unauthorized request. Please check your API key.')
            return None
        else:
            flash(f'Error {response.status_code}: {response.text}')
            return None
    except requests.RequestException as e:
        flash(f'Request failed: {str(e)}')
        return None

if __name__ == '__main__':
    app.run(debug=True)
