from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
import requests
import json
import os
import joblib  # Add this import if your model is saved using joblib

app = Flask(__name__)
app.secret_key = 'supersecretkey'

CONFIG_FILE = 'config.json'

def load_config():
    try:
        with open(CONFIG_FILE, 'r') as file:
            config = json.load(file)
        return config
    except Exception as e:
        print(f"Error loading config file: {e}")
        return None

config = load_config()
MOBSF_API_KEY = config.get('MOBSF_API_KEY') if config else None
API_URL = 'http://localhost:8000/api/v1'

permissions_columns = [
    "ACCEPT_HANDOVER", "ACCESS_BACKGROUND_LOCATION", "ACCESS_CHECKIN_PROPERTIES",
    "ACCESS_COARSE_LOCATION", "ACCESS_FINE_LOCATION", "ACCESS_LOCATION_EXTRA_COMMANDS",
    "ACCESS_MEDIA_LOCATION", "ACCESS_NETWORK_STATE", "ACCESS_NOTIFICATION_POLICY",
    "ACCESS_WIFI_STATE", "ACCOUNT_MANAGER", "ACTIVITY_RECOGNITION", "ADD_VOICEMAIL",
    "ANSWER_PHONE_CALLS", "BATTERY_STATS", "BIND_ACCESSIBILITY_SERVICE", "BIND_APPWIDGET",
    "BIND_AUTOFILL_SERVICE", "BIND_CALL_REDIRECTION_SERVICE", "BIND_CARRIER_MESSAGING_CLIENT_SERVICE",
    "BIND_CARRIER_MESSAGING_SERVICE", "BIND_CARRIER_SERVICES", "BIND_CHOOSER_TARGET_SERVICE",
    "BIND_CONDITION_PROVIDER_SERVICE", "BIND_CONTROLS", "BIND_DEVICE_ADMIN", "BIND_DREAM_SERVICE",
    "BIND_INCALL_SERVICE", "BIND_INPUT_METHOD", "BIND_MIDI_DEVICE_SERVICE", "BIND_NFC_SERVICE",
    "BIND_NOTIFICATION_LISTENER_SERVICE", "BIND_PRINT_SERVICE", "BIND_QUICK_ACCESS_WALLET_SERVICE",
    "BIND_QUICK_SETTINGS_TILE", "BIND_REMOTEVIEWS", "BIND_SCREENING_SERVICE",
    "BIND_TELECOM_CONNECTION_SERVICE", "BIND_TEXT_SERVICE", "BIND_TV_INPUT",
    "BIND_VISUAL_VOICEMAIL_SERVICE", "BIND_VOICE_INTERACTION", "BIND_VPN_SERVICE",
    "BIND_VR_LISTENER_SERVICE", "BIND_WALLPAPER", "BLUETOOTH", "BLUETOOTH_ADMIN",
    "BLUETOOTH_PRIVILEGED", "BODY_SENSORS", "BROADCAST_PACKAGE_REMOVED", "BROADCAST_SMS",
    "BROADCAST_STICKY", "BROADCAST_WAP_PUSH", "CALL_COMPANION_APP", "CALL_PHONE",
    "CALL_PRIVILEGED", "CAMERA", "CAPTURE_AUDIO_OUTPUT", "CHANGE_COMPONENT_ENABLED_STATE",
    "CHANGE_CONFIGURATION", "CHANGE_NETWORK_STATE", "CHANGE_WIFI_MULTICAST_STATE",
    "CHANGE_WIFI_STATE", "CLEAR_APP_CACHE", "CONTROL_LOCATION_UPDATES", "DELETE_CACHE_FILES",
    "DELETE_PACKAGES", "DIAGNOSTIC", "DISABLE_KEYGUARD", "DUMP", "EXPAND_STATUS_BAR",
    "FACTORY_TEST", "FOREGROUND_SERVICE", "GET_ACCOUNTS", "GET_ACCOUNTS_PRIVILEGED",
    "GET_PACKAGE_SIZE", "GET_TASKS", "GLOBAL_SEARCH", "INSTALL_LOCATION_PROVIDER",
    "INSTALL_PACKAGES", "INSTALL_SHORTCUT", "INSTANT_APP_FOREGROUND_SERVICE",
    "INTERACT_ACROSS_PROFILES", "INTERNET", "KILL_BACKGROUND_PROCESSES", "LOADER_USAGE_STATS",
    "LOCATION_HARDWARE", "MANAGE_DOCUMENTS", "MANAGE_EXTERNAL_STORAGE", "MANAGE_OWN_CALLS",
    "MASTER_CLEAR", "MEDIA_CONTENT_CONTROL", "MODIFY_AUDIO_SETTINGS", "MODIFY_PHONE_STATE",
    "MOUNT_FORMAT_FILESYSTEMS", "MOUNT_UNMOUNT_FILESYSTEMS", "NFC",
    "NFC_PREFERRED_PAYMENT_INFO", "NFC_TRANSACTION_EVENT", "PACKAGE_USAGE_STATS",
    "PERSISTENT_ACTIVITY", "PROCESS_OUTGOING_CALLS", "QUERY_ALL_PACKAGES", "READ_CALENDAR",
    "READ_CALL_LOG", "READ_CONTACTS", "READ_EXTERNAL_STORAGE", "READ_INPUT_STATE",
    "READ_LOGS", "READ_PHONE_NUMBERS", "READ_PHONE_STATE", "READ_PRECISE_PHONE_STATE",
    "READ_SMS", "READ_SYNC_SETTINGS", "READ_SYNC_STATS", "READ_VOICEMAIL", "REBOOT",
    "RECEIVE_BOOT_COMPLETED", "RECEIVE_MMS", "RECEIVE_SMS", "RECEIVE_WAP_PUSH",
    "RECORD_AUDIO", "REORDER_TASKS", "REQUEST_COMPANION_RUN_IN_BACKGROUND",
    "REQUEST_COMPANION_USE_DATA_IN_BACKGROUND", "REQUEST_DELETE_PACKAGES",
    "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", "REQUEST_INSTALL_PACKAGES",
    "REQUEST_PASSWORD_COMPLEXITY", "RESTART_PACKAGES", "SEND_RESPOND_VIA_MESSAGE",
    "SEND_SMS", "SET_ALARM", "SET_ALWAYS_FINISH", "SET_ANIMATION_SCALE", "SET_DEBUG_APP",
    "SET_PREFERRED_APPLICATIONS", "SET_PROCESS_LIMIT", "SET_TIME", "SET_TIME_ZONE",
    "SET_WALLPAPER", "SET_WALLPAPER_HINTS", "SIGNAL_PERSISTENT_PROCESSES",
    "SMS_FINANCIAL_TRANSACTIONS", "START_VIEW_PERMISSION_USAGE", "STATUS_BAR",
    "SYSTEM_ALERT_WINDOW", "TRANSMIT_IR", "UNINSTALL_SHORTCUT", "UPDATE_DEVICE_STATS",
    "USE_BIOMETRIC", "USE_FINGERPRINT", "USE_FULL_SCREEN_INTENT", "USE_SIP", "VIBRATE",
    "WAKE_LOCK", "WRITE_APN_SETTINGS", "WRITE_CALENDAR", "WRITE_CALL_LOG", "WRITE_CONTACTS",
    "WRITE_EXTERNAL_STORAGE", "WRITE_GSERVICES", "WRITE_SECURE_SETTINGS", "WRITE_SETTINGS",
    "WRITE_SYNC_SETTINGS", "WRITE_VOICEMAIL", "nr_permissions", "normal", "dangerous",
    "signature", "custom_yes", "nr_custom", "total_perm"
]

# Load your trained model
model = joblib.load(r"C:\Users\Sampreethi Y\Desktop\finall - Copy (2)\fad.pkl")  # Replace with the correct path

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        flash('No file part')
        return redirect(request.url)
    
    file = request.files['file']
    if file.filename == '':
        flash('No selected file')
        return redirect(request.url)
    
    if file:
        files = {'file': (file.filename, file, 'application/vnd.android.package-archive')}
        response = send_request('/upload', 'POST', files=files)
        if response:
            scan_hash = response.get('hash')
            flash(f'File uploaded. Scan hash: {scan_hash}')
            return redirect(url_for('index'))
        else:
            flash('Failed to upload the file.')
            return redirect(url_for('index'))

@app.route('/scan', methods=['POST'])
def scan_file():
    scan_hash = request.form.get('scan_hash')
    if scan_hash:
        response = send_request('/scan', 'POST', data={'hash': scan_hash})
        if response:
            flash('File scanned successfully.')
        else:
            flash('Failed to scan the file.')
    else:
        flash('Please provide a scan hash.')
    return redirect(url_for('index'))

@app.route('/scorecard', methods=['POST'])
def get_scorecard():
    scan_hash = request.form.get('scan_hash')
    if scan_hash:
        response = send_request('/scorecard', 'POST', data={'hash': scan_hash})
        if response:
            file_path = save_to_file(response, f'scorecard_{scan_hash}.json')
            if file_path:
                return send_file(file_path, as_attachment=True)
            else:
                flash('Failed to save the scorecard to a file.')
        else:
            flash('Failed to retrieve the scorecard.')
    else:
        flash('Please provide a scan hash.')
    return redirect(url_for('index'))

@app.route('/report_json', methods=['POST'])
def generate_json_report():
    scan_hash = request.form.get('scan_hash')
    if scan_hash:
        response = send_request('/report_json', 'POST', data={'hash': scan_hash})
        if response:
            file_path = save_to_file(response, f'report_{scan_hash}.json')
            if file_path:
                return send_file(file_path, as_attachment=True)
            else:
                flash('Failed to save the JSON report to a file.')
        else:
            flash('Failed to generate JSON report.')
    else:
        flash('Please provide a scan hash.')
    return redirect(url_for('index'))

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        flash('No file part')
        return redirect(request.url)
    
    file = request.files['file']
    if file.filename == '':
        flash('No selected file')
        return redirect(request.url)
    
    if file:
        try:
            data = json.load(file)
            feature_list = extract_features(data)
            
            # Convert the feature list to the correct shape for your model
            feature_vector = [feature_list]  # Assuming the model expects a 2D array

            # Perform the prediction
            prediction = model.predict(feature_vector)
            prediction_proba = model.predict_proba(feature_vector)  # If you want probabilities

            flash(f'Prediction: {prediction[0]}')
            flash(f'Prediction Probability: {prediction_proba}')
        except Exception as e:
            flash(f'Error processing file: {e}')
    
    return redirect(url_for('index'))

def extract_features(data):
    feature_dict = {}
    for permission in permissions_columns:
        if permission in ["nr_permissions", "normal", "dangerous", "signature", "custom_yes", "nr_custom", "total_perm"]:
            feature_dict[permission] = data.get(permission, 0)
        else:
            feature_dict[permission] = 1 if permission in data.get('permissions', []) else 0
    
    return [feature_dict[perm] for perm in permissions_columns]

def send_request(endpoint, method='GET', files=None, data=None, params=None):
    url = f'{API_URL}{endpoint}'
    headers = {'Authorization': MOBSF_API_KEY}
    try:
        if method == 'POST':
            if files:
                response = requests.post(url, headers=headers, files=files)
            else:
                response = requests.post(url, headers=headers, data=data)
        elif method == 'GET':
            response = requests.get(url, headers=headers, params=params)
        
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 401:
            flash('Unauthorized request. Please check your API key.')
            return None
        else:
            flash(f'Error {response.status_code}: {response.text}')
            return None
    except requests.RequestException as e:
        flash(f'Request failed: {str(e)}')
        return None

def save_to_file(data, filename):
    try:
        with open(filename, 'w') as file:
            json.dump(data, file, indent=4)
        return filename
    except Exception as e:
        print(f"Error saving file: {e}")
        return None

if __name__ == '__main__':
    app.run(debug=True)
